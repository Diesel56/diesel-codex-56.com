# get_codex.py
import sys
from pathlib import Path
from datetime import datetime

VAULT_PATH = Path.home() / "jimmy.recourse" / "vault" / "context"
VAULT_PATH.mkdir(parents=True, exist_ok=True)

pattern = "default"
if "--pattern" in sys.argv:
    idx = sys.argv.index("--pattern")
    if idx + 1 < len(sys.argv):
        pattern = sys.argv[idx + 1]

timestamp = datetime.now().strftime("%Y-%m-%d_%H-%M-%S")
filename = VAULT_PATH / f"codex-{pattern.replace(' ', '-')}-{timestamp}.yaml"

content = f"title: {pattern}\ncontent: |\n  Codex entry for pattern: {pattern}\nEOF\n"

with open(filename, "w") as f:
    f.write(content)

print(f"📦 Codex for pattern '{pattern}' written to: {filename}")
