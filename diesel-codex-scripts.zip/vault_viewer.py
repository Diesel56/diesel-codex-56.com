# vault_viewer.py
from pathlib import Path

VAULT_PATH = Path.home() / "jimmy.recourse" / "vault" / "context"

print("📂 Diesel Vault Contents:\n")
for f in sorted(VAULT_PATH.glob("*.yaml")):
    print(f"- {f.name}")
