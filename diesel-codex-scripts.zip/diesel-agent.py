# diesel-agent.py
import os
from datetime import datetime
from pathlib import Path
import json

VAULT_PATH = Path.home() / "jimmy.recourse" / "vault" / "context"
MANIFEST_FILE = VAULT_PATH / "manifest.json"

def scan_vault():
    files = list(VAULT_PATH.glob("*.yaml"))
    return [{"file": f.name, "modified": f.stat().st_mtime} for f in files]

def update_manifest():
    manifest = {
        "updated": datetime.now().isoformat(),
        "files": scan_vault()
    }
    with open(MANIFEST_FILE, "w") as f:
        json.dump(manifest, f, indent=2)
    print(f"🧠 Manifest updated with {len(manifest['files'])} files")

if __name__ == "__main__":
    update_manifest()
