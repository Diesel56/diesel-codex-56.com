# whisper-cli.py
from datetime import datetime
from pathlib import Path

VAULT_PATH = Path.home() / "jimmy.recourse" / "vault" / "context"
VAULT_PATH.mkdir(parents=True, exist_ok=True)

timestamp = datetime.now().strftime("%Y-%m-%d_%H-%M-%S")
filename = VAULT_PATH / f"transcript-{timestamp}.yaml"

with open(filename, "w") as f:
    f.write("title: Untitled\ncontent: |\n  This is a simulated voice note.\nEOF\n")

print(f"🎙️ Simulated voice capture...\n✅ Voice transcript saved as: {filename}")
